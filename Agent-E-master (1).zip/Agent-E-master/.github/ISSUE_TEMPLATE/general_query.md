---
name: General Query
about: Ask a question or seek clarification about the project
title: "[QUERY] "
labels: question
---

### Title
[Short description of the query]

### Description
Please provide a detailed description of your question or general query.

### Additional Context
Add any other context or information that could help in addressing your query.
